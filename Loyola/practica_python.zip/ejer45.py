import math
r = float(input())

print('area:', round(math.pi * r**2, 2), 'perimetro:', round(2*math.pi*r, 2) )