

print(str("{0:.3f}".format(5011/10000)))