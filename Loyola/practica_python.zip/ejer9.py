import math
print(math.pi * (input('Ingrese el radio: ') **2))