c = int(input())
x = float(input())
n = int(input())
print(c*(1+x/100)**n)
