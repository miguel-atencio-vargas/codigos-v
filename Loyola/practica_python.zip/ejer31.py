a =int( input('ingrese un lado del cuadrado: '))
print('perimetro: ', a*4, 'area: ', a**2 , 'm2' )