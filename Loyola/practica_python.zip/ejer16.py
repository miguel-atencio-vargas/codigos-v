# print(1/2/4.0)
# print(1/2.0/4.0)
# print(1/2.0/4)
# print(1.0/2/4)
# print(4.0**((1/2)))
# print(3/2)

print(True == True != False)

