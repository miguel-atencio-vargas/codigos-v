a = int(input())
if (a-2) %4 ==0:
    print(int(a/2))