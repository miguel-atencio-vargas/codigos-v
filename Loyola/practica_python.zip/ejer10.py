x = input('Ingrese el valor para calcular el IVA: ')
print(x+(x*0.16))