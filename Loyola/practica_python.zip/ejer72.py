a = int(input())
print(a.)



if a >= 65 and a <= 90:
    print('ES MAYUSCULA')
elif a>= 97 and a<=122:
    print('es minuscula')