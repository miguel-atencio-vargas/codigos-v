
a = input()
if '.' in a: a = float(a)
else: a = int(a)


print('perimetro:',a*4, 'area:',a**2)