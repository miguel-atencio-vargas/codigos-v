import turtle 

t = turtle.Turtle()

for i in range(4):
    t.forward(100)
    t.right(90)

t.right(45)
t.forward(141)

t.right(135)
t.forward(100)

t.right(135)
t.forward(141)
turtle.done()