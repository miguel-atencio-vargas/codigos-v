import math

b =  int(math.exp(2*math.log(3)))


a = math.degrees(math.sin(3*math.pi/2))

c = round(3.21123 * math.log10(1000), 3)
print(c)