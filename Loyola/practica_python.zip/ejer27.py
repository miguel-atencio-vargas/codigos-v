
import math
print(float(round(abs(-3.4))))