import math
a = float(input())
b = float(input())


g = math.radians(int(input()))
print(0.5*a*b*math.sin(g))

